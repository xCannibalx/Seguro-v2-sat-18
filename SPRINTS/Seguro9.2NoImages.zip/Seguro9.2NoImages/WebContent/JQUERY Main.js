$(document).ready(function(){
   $("#mainskate").animate({left:"70%"},1000);
    $("#mainmsg").slideDown(1000);
    $("#mainmsg2").delay(500).slideDown(1000);
});